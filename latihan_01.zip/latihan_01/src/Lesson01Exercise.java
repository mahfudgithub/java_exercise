public class Lesson01Exercise
{
	public static void main(String[] args)
	{
		System.out.printf("hi Mahfudin, Selamat datang dalam bahasa Pemrograman Java");	
	}
}